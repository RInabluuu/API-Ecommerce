const express = require("express");
const app = express();
const errorMiddleware = require("./middleware/error.middleware");

app.use(express.json());

app.use("/api/v1/users", require("./routes/user.routes"));
app.use("/api/v1/products", require("./routes/product.routes"));
app.use("/api/v1/orders", require("./routes/order.routes"));

app.use(errorMiddleware);

module.exports = app;
