const { orders, processedKeys } = require("../data/db");

exports.createOrder = (req, res) => {
  const { items } = req.body;
  const idempotencyKey = req.headers['x-idempotency-key'];

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "Items must be a non-empty array" });
  }

  if (!idempotencyKey) {
    return res.status(400).json({ message: "X-Idempotency-Key header is required" });
  }
  if (processedKeys.has(idempotencyKey)) {
    return res.status(409).json({ message: "Duplicate request detected" });
  }

  const order = {
    id: orders.length + 1,
    user: req.user.username,
    items,
    status: "pending",
    createdAt: new Date()
  };

  orders.push(order);
  processedKeys.add(idempotencyKey);

  res.status(201).json(order);
};
