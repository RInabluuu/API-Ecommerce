const { products } = require("../data/db");

exports.getProducts = (req, res) => {
  res.json(products);
};
