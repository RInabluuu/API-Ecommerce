const jwt = require("jsonwebtoken");
const SECRET = "your-secure-secret-key";

exports.login = (req, res) => {
  const { username, password } = req.body;

  let role = "customer";
  if (username === "admin" && password === "1234") {
    role = "admin";
  } else if (username === "user1" && password === "1234") {
    role = "customer";
  } else {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign({ username, role }, SECRET, { expiresIn: "1h" });
  res.json({ message: "Login successful", token });
};
