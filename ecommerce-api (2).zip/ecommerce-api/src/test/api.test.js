const request = require('supertest');
const app = require('../app');

describe('E-commerce API Integration Tests', () => {
  let adminToken;
  let userToken;

  test('POST /api/v1/users/login - ควร Login สำเร็จและได้ Token', async () => {
    const res = await request(app)
      .post('/api/v1/users/login')
      .send({ username: 'admin', password: '1234' });
    
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('token');
    adminToken = res.body.token;
  });

  test('POST /api/v1/orders - ควร Error 400 ถ้าลืมใส่ Idempotency Key', async () => {
    const res = await request(app)
      .post('/api/v1/orders')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ items: [{ id: 1, quantity: 1 }] });
    
    expect(res.statusCode).toEqual(400);
    expect(res.body.message).toBe("X-Idempotency-Key header is required");
  });

  test('POST /api/v1/orders - ควร Error 409 ถ้าส่ง Idempotency Key ซ้ำ', async () => {
    const orderData = { items: [{ id: 1, quantity: 1 }] };
    const key = 'test-key-123';

    await request(app)
      .post('/api/v1/orders')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Idempotency-Key', key)
      .send(orderData);

    const res = await request(app)
      .post('/api/v1/orders')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Idempotency-Key', key)
      .send(orderData);
    
    expect(res.statusCode).toEqual(409);
    expect(res.body.message).toBe("Duplicate request detected");
  });
});
