const { orders } = require("../data/db");

exports.createOrder = (req, res) => {
  const order = {
    id: orders.length + 1,
    user: req.user.username,
    items: req.body.items
  };

  orders.push(order);
  res.status(201).json(order);
};
