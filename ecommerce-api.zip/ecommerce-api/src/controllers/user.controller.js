const jwt = require("jsonwebtoken");

exports.login = (req, res) => {
  const { username, password } = req.body;

  if (username !== "admin" || password !== "1234") {
    return res.status(401).json({
      message: "Invalid credentials"
    });
  }

  const token = jwt.sign(
    { username },
    "secretkey",
    { expiresIn: "1h" }
  );

  res.json({
    message: "Login successful",
    token
  });
};
