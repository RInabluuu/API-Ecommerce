exports.products = [
  { id: 1, name: "Laptop", price: 25000 },
  { id: 2, name: "Phone", price: 15000 }
];

exports.orders = [];
