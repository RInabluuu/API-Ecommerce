const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth.middleware");
const { orders } = require("../data/db");

// CREATE ORDER
router.post("/", auth, (req, res) => {
  const order = {
    id: orders.length + 1,
    user: req.user.username,
    items: req.body.items || []
  };

  orders.push(order);
  res.status(201).json(order);
});

// GET ALL ORDERS  <<<<< อันนี้แหละที่ขาด
router.get("/", auth, (req, res) => {
  res.json(orders);
});

module.exports = router;

